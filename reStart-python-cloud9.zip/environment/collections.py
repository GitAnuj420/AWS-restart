fruits = ["Apple","Banana","Orange"]
print(fruits)
print(type(fruits))
print(fruits[0])
print(fruits[1])
print(fruits[2])
print(type(fruits[0]))
print(type(fruits[1]))
print(type(fruits[2]))
myFavoriteFruitDictionary = {
  "Akua" : "apple",
  "Saanvi" : "banana",
  "Paulo" : "pineapple"
}
print(myFavoriteFruitDictionary)
print(myFavoriteFruitDictionary["Akua"])