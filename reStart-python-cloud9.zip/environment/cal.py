
myValue=3j
print(type(myValue))